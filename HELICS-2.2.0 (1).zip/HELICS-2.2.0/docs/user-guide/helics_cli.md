# helics_cli #

This section will describe the uses of helics_cli and how to configure it for configuring federates and launching co-simulations.
