Types of Federates
==================

1)  Value Federates

    - Direct Fixed Connections to other Federates
    - Physical values being sent back and forth
    - Associated Units

2)  Message Federates

    - Packets of data
    - No fixed connections
    - For things such as Events, Communication packets, triggers

3)  Combination Federate (Value+Message Federate)

4) While not a separate type Filters are supported on all federate types and could be created on a simple federate that doesn't otherwise support value or Message interfaces.  
