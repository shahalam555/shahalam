Run tests
=========

**Python**

To run the python tests, first install pytest

```bash
pip install pytest
```

Then run it by doing the following

```bash
cd ~/GitRepos/HELICS/tests/
pytest -sv python_helics
```

