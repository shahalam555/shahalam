Developer Guide
===============

```eval_rst
.. toctree::
   :maxdepth: 1

   style
   swig
   tests
   docs
   continuous-integration
   ../Public_API
```
