function varargout = helicsFederateGetFilterCount(varargin)
  [varargout{1:nargout}] = helicsMEX(269, varargin{:});
end
