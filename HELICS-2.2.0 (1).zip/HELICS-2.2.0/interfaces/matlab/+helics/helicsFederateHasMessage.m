function varargout = helicsFederateHasMessage(varargin)
  [varargout{1:nargout}] = helicsMEX(222, varargin{:});
end
