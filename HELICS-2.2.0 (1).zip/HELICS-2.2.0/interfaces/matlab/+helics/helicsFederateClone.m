function varargout = helicsFederateClone(varargin)
  [varargout{1:nargout}] = helicsMEX(68, varargin{:});
end
