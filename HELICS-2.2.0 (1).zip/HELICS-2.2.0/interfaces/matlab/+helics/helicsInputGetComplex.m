function varargout = helicsInputGetComplex(varargin)
  [varargout{1:nargout}] = helicsMEX(174, varargin{:});
end
