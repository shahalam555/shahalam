function varargout = helicsFederateRegisterCloningFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(265, varargin{:});
end
