function varargout = helicsInputSetDefaultChar(varargin)
  [varargout{1:nargout}] = helicsMEX(183, varargin{:});
end
