function varargout = helicsInputClearUpdate(varargin)
  [varargout{1:nargout}] = helicsMEX(208, varargin{:});
end
