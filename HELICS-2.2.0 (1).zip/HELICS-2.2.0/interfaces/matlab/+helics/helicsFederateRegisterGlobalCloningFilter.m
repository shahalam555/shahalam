function varargout = helicsFederateRegisterGlobalCloningFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(266, varargin{:});
end
