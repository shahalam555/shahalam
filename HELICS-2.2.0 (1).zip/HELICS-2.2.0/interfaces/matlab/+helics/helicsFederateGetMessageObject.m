function varargout = helicsFederateGetMessageObject(varargin)
  [varargout{1:nargout}] = helicsMEX(229, varargin{:});
end
