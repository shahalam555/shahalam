function varargout = helicsInputGetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(202, varargin{:});
end
