function varargout = helicsFederateIsValid(varargin)
  [varargout{1:nargout}] = helicsMEX(73, varargin{:});
end
