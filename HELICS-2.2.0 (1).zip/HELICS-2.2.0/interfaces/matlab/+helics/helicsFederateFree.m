function varargout = helicsFederateFree(varargin)
  [varargout{1:nargout}] = helicsMEX(93, varargin{:});
end
