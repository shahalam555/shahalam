function varargout = helicsFilterAddDestinationTarget(varargin)
  [varargout{1:nargout}] = helicsMEX(275, varargin{:});
end
