function varargout = helicsFederateEnterInitializingMode(varargin)
  [varargout{1:nargout}] = helicsMEX(95, varargin{:});
end
