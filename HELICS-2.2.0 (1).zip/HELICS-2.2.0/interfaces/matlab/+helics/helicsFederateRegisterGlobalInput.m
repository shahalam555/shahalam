function varargout = helicsFederateRegisterGlobalInput(varargin)
  [varargout{1:nargout}] = helicsMEX(143, varargin{:});
end
