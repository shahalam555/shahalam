function varargout = helicsFederateClearMessages(varargin)
  [varargout{1:nargout}] = helicsMEX(231, varargin{:});
end
