function varargout = helicsInputGetTime(varargin)
  [varargout{1:nargout}] = helicsMEX(172, varargin{:});
end
