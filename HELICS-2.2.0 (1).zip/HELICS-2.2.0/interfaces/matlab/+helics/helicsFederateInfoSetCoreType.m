function varargout = helicsFederateInfoSetCoreType(varargin)
  [varargout{1:nargout}] = helicsMEX(77, varargin{:});
end
