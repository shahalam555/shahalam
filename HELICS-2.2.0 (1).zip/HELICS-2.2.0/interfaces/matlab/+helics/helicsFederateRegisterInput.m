function varargout = helicsFederateRegisterInput(varargin)
  [varargout{1:nargout}] = helicsMEX(141, varargin{:});
end
