function varargout = helicsFederateEnterExecutingModeComplete(varargin)
  [varargout{1:nargout}] = helicsMEX(101, varargin{:});
end
