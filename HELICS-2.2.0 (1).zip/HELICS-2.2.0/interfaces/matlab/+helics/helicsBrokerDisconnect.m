function varargout = helicsBrokerDisconnect(varargin)
  [varargout{1:nargout}] = helicsMEX(56, varargin{:});
end
