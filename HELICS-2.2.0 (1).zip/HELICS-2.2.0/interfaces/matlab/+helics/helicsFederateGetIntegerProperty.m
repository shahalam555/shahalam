function varargout = helicsFederateGetIntegerProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(122, varargin{:});
end
