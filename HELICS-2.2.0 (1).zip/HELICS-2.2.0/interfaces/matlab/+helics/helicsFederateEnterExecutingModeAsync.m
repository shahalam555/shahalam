function varargout = helicsFederateEnterExecutingModeAsync(varargin)
  [varargout{1:nargout}] = helicsMEX(100, varargin{:});
end
