function varargout = helicsFederateRegisterGlobalFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(264, varargin{:});
end
