function varargout = helicsInputGetString(varargin)
  [varargout{1:nargout}] = helicsMEX(168, varargin{:});
end
