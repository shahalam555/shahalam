function varargout = helicsFederateInfoSetTimeProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(87, varargin{:});
end
