function varargout = helicsFederateInfoSetIntegerProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(88, varargin{:});
end
