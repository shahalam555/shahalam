function varargout = helicsFederateGetEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(213, varargin{:});
end
