function varargout = helicsInputGetExtractionUnits(varargin)
  [varargout{1:nargout}] = helicsMEX(196, varargin{:});
end
