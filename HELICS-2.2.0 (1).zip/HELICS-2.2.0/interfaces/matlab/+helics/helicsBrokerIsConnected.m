function varargout = helicsBrokerIsConnected(varargin)
  [varargout{1:nargout}] = helicsMEX(41, varargin{:});
end
