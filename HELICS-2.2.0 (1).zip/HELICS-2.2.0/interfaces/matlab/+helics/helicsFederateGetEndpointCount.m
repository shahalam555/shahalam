function varargout = helicsFederateGetEndpointCount(varargin)
  [varargout{1:nargout}] = helicsMEX(235, varargin{:});
end
