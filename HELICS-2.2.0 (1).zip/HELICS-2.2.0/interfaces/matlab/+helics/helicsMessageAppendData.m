function varargout = helicsMessageAppendData(varargin)
  [varargout{1:nargout}] = helicsMEX(262, varargin{:});
end
