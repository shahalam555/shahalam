function varargout = helicsEndpointGetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(239, varargin{:});
end
