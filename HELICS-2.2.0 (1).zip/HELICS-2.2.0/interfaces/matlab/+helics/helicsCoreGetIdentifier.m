function varargout = helicsCoreGetIdentifier(varargin)
  [varargout{1:nargout}] = helicsMEX(51, varargin{:});
end
