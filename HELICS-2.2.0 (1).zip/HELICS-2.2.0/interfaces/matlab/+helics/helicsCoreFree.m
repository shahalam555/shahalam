function varargout = helicsCoreFree(varargin)
  [varargout{1:nargout}] = helicsMEX(60, varargin{:});
end
