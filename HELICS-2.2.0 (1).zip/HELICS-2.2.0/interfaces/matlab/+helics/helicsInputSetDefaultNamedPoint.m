function varargout = helicsInputSetDefaultNamedPoint(varargin)
  [varargout{1:nargout}] = helicsMEX(187, varargin{:});
end
