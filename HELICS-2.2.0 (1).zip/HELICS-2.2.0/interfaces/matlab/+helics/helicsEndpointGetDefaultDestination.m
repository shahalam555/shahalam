function varargout = helicsEndpointGetDefaultDestination(varargin)
  [varargout{1:nargout}] = helicsMEX(216, varargin{:});
end
