function varargout = helicsGetPropertyIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(83, varargin{:});
end
