function varargout = helicsCreateBroker(varargin)
  [varargout{1:nargout}] = helicsMEX(37, varargin{:});
end
