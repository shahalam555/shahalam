function varargout = helicsCloseLibrary(varargin)
  [varargout{1:nargout}] = helicsMEX(94, varargin{:});
end
