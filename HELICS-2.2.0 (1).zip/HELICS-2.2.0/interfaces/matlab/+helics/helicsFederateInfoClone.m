function varargout = helicsFederateInfoClone(varargin)
  [varargout{1:nargout}] = helicsMEX(70, varargin{:});
end
