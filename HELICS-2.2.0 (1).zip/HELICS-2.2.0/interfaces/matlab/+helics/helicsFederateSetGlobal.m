function varargout = helicsFederateSetGlobal(varargin)
  [varargout{1:nargout}] = helicsMEX(124, varargin{:});
end
