function varargout = helicsCoreSetGlobal(varargin)
  [varargout{1:nargout}] = helicsMEX(125, varargin{:});
end
