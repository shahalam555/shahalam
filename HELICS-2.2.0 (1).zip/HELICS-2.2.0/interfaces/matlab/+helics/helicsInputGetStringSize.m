function varargout = helicsInputGetStringSize(varargin)
  [varargout{1:nargout}] = helicsMEX(167, varargin{:});
end
