function varargout = helicsFederateRegisterGlobalTypePublication(varargin)
  [varargout{1:nargout}] = helicsMEX(140, varargin{:});
end
