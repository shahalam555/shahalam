function varargout = helicsFederateSetTimeProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(116, varargin{:});
end
