function varargout = helicsInputGetPublicationType(varargin)
  [varargout{1:nargout}] = helicsMEX(189, varargin{:});
end
