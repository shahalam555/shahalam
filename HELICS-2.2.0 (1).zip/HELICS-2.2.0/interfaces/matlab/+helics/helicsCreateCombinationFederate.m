function varargout = helicsCreateCombinationFederate(varargin)
  [varargout{1:nargout}] = helicsMEX(66, varargin{:});
end
