function varargout = helicsFederateEnterExecutingModeIterative(varargin)
  [varargout{1:nargout}] = helicsMEX(102, varargin{:});
end
