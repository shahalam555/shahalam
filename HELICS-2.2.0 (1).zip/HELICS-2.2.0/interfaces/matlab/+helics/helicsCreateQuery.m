function varargout = helicsCreateQuery(varargin)
  [varargout{1:nargout}] = helicsMEX(127, varargin{:});
end
