function varargout = helicsBrokerSetGlobal(varargin)
  [varargout{1:nargout}] = helicsMEX(126, varargin{:});
end
