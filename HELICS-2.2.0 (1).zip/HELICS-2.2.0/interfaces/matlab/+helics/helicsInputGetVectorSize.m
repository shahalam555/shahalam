function varargout = helicsInputGetVectorSize(varargin)
  [varargout{1:nargout}] = helicsMEX(175, varargin{:});
end
