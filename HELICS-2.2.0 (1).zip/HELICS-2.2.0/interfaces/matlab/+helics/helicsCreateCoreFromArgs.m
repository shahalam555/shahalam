function varargout = helicsCreateCoreFromArgs(varargin)
  [varargout{1:nargout}] = helicsMEX(34, varargin{:});
end
