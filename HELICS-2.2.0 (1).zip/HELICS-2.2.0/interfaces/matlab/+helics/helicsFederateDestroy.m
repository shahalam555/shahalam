function varargout = helicsFederateDestroy(varargin)
  [varargout{1:nargout}] = helicsMEX(57, varargin{:});
end
