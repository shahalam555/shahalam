function varargout = helicsFederateRequestTimeComplete(varargin)
  [varargout{1:nargout}] = helicsMEX(112, varargin{:});
end
