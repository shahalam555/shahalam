function varargout = helicsFederateFinalize(varargin)
  [varargout{1:nargout}] = helicsMEX(90, varargin{:});
end
