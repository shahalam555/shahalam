function varargout = helicsFederateSetIntegerProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(119, varargin{:});
end
