function varargout = helicsFederateRegisterFromPublicationJSON(varargin)
  [varargout{1:nargout}] = helicsMEX(151, varargin{:});
end
