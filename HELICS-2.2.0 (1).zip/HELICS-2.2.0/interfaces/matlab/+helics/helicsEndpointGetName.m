function varargout = helicsEndpointGetName(varargin)
  [varargout{1:nargout}] = helicsMEX(234, varargin{:});
end
