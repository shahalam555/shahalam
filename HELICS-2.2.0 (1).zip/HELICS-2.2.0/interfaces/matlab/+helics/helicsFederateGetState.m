function varargout = helicsFederateGetState(varargin)
  [varargout{1:nargout}] = helicsMEX(105, varargin{:});
end
