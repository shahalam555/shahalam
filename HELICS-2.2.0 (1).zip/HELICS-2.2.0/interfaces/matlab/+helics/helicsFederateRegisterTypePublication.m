function varargout = helicsFederateRegisterTypePublication(varargin)
  [varargout{1:nargout}] = helicsMEX(138, varargin{:});
end
