function varargout = helicsEndpointSendMessageRaw(varargin)
  [varargout{1:nargout}] = helicsMEX(217, varargin{:});
end
