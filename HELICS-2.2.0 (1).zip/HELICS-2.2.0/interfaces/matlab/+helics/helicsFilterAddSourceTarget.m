function varargout = helicsFilterAddSourceTarget(varargin)
  [varargout{1:nargout}] = helicsMEX(276, varargin{:});
end
