function varargout = helicsFederateRequestNextStep(varargin)
  [varargout{1:nargout}] = helicsMEX(109, varargin{:});
end
