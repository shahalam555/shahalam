function varargout = helicsBrokerDataLink(varargin)
  [varargout{1:nargout}] = helicsMEX(42, varargin{:});
end
