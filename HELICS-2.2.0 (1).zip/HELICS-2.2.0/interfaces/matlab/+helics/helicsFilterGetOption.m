function varargout = helicsFilterGetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(283, varargin{:});
end
