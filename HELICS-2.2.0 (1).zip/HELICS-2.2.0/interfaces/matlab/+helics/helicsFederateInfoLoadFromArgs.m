function varargout = helicsFederateInfoLoadFromArgs(varargin)
  [varargout{1:nargout}] = helicsMEX(71, varargin{:});
end
