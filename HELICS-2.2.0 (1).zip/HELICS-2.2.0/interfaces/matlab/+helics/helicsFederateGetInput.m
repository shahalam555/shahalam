function varargout = helicsFederateGetInput(varargin)
  [varargout{1:nargout}] = helicsMEX(147, varargin{:});
end
