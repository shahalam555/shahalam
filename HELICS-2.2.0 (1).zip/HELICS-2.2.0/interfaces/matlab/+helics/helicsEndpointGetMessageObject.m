function varargout = helicsEndpointGetMessageObject(varargin)
  [varargout{1:nargout}] = helicsMEX(227, varargin{:});
end
