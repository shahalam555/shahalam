function varargout = helicsInputGetNamedPoint(varargin)
  [varargout{1:nargout}] = helicsMEX(177, varargin{:});
end
