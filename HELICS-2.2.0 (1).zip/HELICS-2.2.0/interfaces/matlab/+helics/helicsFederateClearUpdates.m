function varargout = helicsFederateClearUpdates(varargin)
  [varargout{1:nargout}] = helicsMEX(150, varargin{:});
end
