function varargout = helicsFederateInfoSetLocalPort(varargin)
  [varargout{1:nargout}] = helicsMEX(82, varargin{:});
end
