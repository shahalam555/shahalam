function varargout = helicsFilterAddDeliveryEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(277, varargin{:});
end
