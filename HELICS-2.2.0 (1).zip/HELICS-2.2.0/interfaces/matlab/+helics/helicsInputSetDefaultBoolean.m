function varargout = helicsInputSetDefaultBoolean(varargin)
  [varargout{1:nargout}] = helicsMEX(181, varargin{:});
end
