function varargout = helicsBrokerDestroy(varargin)
  [varargout{1:nargout}] = helicsMEX(58, varargin{:});
end
