function varargout = helicsBrokerGetAddress(varargin)
  [varargout{1:nargout}] = helicsMEX(52, varargin{:});
end
