function varargout = helicsFederateInfoSetBroker(varargin)
  [varargout{1:nargout}] = helicsMEX(79, varargin{:});
end
