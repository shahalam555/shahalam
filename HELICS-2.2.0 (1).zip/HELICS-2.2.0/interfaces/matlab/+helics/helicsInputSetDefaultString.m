function varargout = helicsInputSetDefaultString(varargin)
  [varargout{1:nargout}] = helicsMEX(179, varargin{:});
end
