function varargout = helicsCreateMessageFederate(varargin)
  [varargout{1:nargout}] = helicsMEX(64, varargin{:});
end
