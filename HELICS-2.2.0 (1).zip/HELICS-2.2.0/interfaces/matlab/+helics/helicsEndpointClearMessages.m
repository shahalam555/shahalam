function varargout = helicsEndpointClearMessages(varargin)
  [varargout{1:nargout}] = helicsMEX(232, varargin{:});
end
