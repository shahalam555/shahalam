function varargout = helicsFederateInfoSetBrokerKey(varargin)
  [varargout{1:nargout}] = helicsMEX(80, varargin{:});
end
