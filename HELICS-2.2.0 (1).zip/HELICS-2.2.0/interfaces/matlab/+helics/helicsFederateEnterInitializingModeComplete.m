function varargout = helicsFederateEnterInitializingModeComplete(varargin)
  [varargout{1:nargout}] = helicsMEX(98, varargin{:});
end
