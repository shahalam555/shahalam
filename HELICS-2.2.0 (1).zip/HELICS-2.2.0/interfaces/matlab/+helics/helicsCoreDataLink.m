function varargout = helicsCoreDataLink(varargin)
  [varargout{1:nargout}] = helicsMEX(47, varargin{:});
end
