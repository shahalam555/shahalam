function varargout = helicsCoreClone(varargin)
  [varargout{1:nargout}] = helicsMEX(35, varargin{:});
end
