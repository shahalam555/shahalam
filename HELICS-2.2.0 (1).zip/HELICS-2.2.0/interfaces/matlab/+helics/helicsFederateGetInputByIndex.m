function varargout = helicsFederateGetInputByIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(148, varargin{:});
end
