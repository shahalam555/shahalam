function varargout = helicsFederateSetFlagOption(varargin)
  [varargout{1:nargout}] = helicsMEX(117, varargin{:});
end
