function varargout = helicsEndpointGetType(varargin)
  [varargout{1:nargout}] = helicsMEX(233, varargin{:});
end
