function varargout = helicsFederateGetPublicationByIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(146, varargin{:});
end
