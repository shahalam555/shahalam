function varargout = helicsFederateGetCurrentTime(varargin)
  [varargout{1:nargout}] = helicsMEX(123, varargin{:});
end
