function varargout = helicsInputGetInteger(varargin)
  [varargout{1:nargout}] = helicsMEX(169, varargin{:});
end
