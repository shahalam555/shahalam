function varargout = helicsFederateGetEndpointByIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(214, varargin{:});
end
