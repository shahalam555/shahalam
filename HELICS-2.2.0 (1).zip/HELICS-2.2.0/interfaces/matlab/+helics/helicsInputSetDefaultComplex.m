function varargout = helicsInputSetDefaultComplex(varargin)
  [varargout{1:nargout}] = helicsMEX(185, varargin{:});
end
