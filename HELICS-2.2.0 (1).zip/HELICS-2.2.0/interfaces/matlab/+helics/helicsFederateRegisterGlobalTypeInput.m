function varargout = helicsFederateRegisterGlobalTypeInput(varargin)
  [varargout{1:nargout}] = helicsMEX(144, varargin{:});
end
