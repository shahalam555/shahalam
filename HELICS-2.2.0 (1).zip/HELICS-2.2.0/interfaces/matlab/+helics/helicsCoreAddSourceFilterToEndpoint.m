function varargout = helicsCoreAddSourceFilterToEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(48, varargin{:});
end
