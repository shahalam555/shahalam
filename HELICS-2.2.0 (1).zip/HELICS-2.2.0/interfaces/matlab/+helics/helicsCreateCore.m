function varargout = helicsCreateCore(varargin)
  [varargout{1:nargout}] = helicsMEX(33, varargin{:});
end
