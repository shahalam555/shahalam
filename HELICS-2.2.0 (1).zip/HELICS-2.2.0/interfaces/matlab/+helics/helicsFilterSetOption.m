function varargout = helicsFilterSetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(282, varargin{:});
end
