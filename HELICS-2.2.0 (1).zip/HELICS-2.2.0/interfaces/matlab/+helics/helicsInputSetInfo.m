function varargout = helicsInputSetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(199, varargin{:});
end
