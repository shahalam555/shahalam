function varargout = helicsFederateInfoSetFlagOption(varargin)
  [varargout{1:nargout}] = helicsMEX(85, varargin{:});
end
