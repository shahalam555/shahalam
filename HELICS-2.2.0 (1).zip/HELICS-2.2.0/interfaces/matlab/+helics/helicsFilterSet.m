function varargout = helicsFilterSet(varargin)
  [varargout{1:nargout}] = helicsMEX(273, varargin{:});
end
