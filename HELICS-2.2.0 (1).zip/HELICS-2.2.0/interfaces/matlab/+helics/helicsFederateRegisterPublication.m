function varargout = helicsFederateRegisterPublication(varargin)
  [varargout{1:nargout}] = helicsMEX(137, varargin{:});
end
