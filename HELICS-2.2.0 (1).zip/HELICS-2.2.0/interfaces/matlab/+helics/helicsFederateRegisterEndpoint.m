function varargout = helicsFederateRegisterEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(211, varargin{:});
end
