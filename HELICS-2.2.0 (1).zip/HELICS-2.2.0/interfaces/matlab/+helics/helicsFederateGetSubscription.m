function varargout = helicsFederateGetSubscription(varargin)
  [varargout{1:nargout}] = helicsMEX(149, varargin{:});
end
