function varargout = helicsFilterGetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(280, varargin{:});
end
