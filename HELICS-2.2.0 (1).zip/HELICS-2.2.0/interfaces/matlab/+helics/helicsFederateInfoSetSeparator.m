function varargout = helicsFederateInfoSetSeparator(varargin)
  [varargout{1:nargout}] = helicsMEX(86, varargin{:});
end
