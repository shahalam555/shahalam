function varargout = helicsInputSetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(203, varargin{:});
end
