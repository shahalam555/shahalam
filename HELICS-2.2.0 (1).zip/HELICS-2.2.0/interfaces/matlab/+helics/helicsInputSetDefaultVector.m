function varargout = helicsInputSetDefaultVector(varargin)
  [varargout{1:nargout}] = helicsMEX(186, varargin{:});
end
