function varargout = helicsCoreRegisterFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(267, varargin{:});
end
