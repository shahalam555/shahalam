function varargout = helicsBrokerClone(varargin)
  [varargout{1:nargout}] = helicsMEX(39, varargin{:});
end
