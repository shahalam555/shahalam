function varargout = helicsFederateRegisterGlobalPublication(varargin)
  [varargout{1:nargout}] = helicsMEX(139, varargin{:});
end
