function varargout = helicsFilterRemoveDeliveryEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(279, varargin{:});
end
