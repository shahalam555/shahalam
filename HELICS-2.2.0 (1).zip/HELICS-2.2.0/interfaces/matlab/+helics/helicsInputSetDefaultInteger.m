function varargout = helicsInputSetDefaultInteger(varargin)
  [varargout{1:nargout}] = helicsMEX(180, varargin{:});
end
