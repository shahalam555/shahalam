function varargout = helicsCoreRegisterCloningFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(268, varargin{:});
end
