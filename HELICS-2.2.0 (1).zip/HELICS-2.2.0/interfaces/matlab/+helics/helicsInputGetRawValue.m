function varargout = helicsInputGetRawValue(varargin)
  [varargout{1:nargout}] = helicsMEX(166, varargin{:});
end
