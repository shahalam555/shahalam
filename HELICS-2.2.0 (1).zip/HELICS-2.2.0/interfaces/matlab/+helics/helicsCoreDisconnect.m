function varargout = helicsCoreDisconnect(varargin)
  [varargout{1:nargout}] = helicsMEX(54, varargin{:});
end
