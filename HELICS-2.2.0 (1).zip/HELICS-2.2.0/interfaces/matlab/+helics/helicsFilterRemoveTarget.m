function varargout = helicsFilterRemoveTarget(varargin)
  [varargout{1:nargout}] = helicsMEX(278, varargin{:});
end
