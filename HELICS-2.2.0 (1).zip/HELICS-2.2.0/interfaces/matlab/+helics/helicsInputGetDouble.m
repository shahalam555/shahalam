function varargout = helicsInputGetDouble(varargin)
  [varargout{1:nargout}] = helicsMEX(171, varargin{:});
end
