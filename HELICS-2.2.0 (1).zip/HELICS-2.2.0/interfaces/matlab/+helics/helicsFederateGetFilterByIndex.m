function varargout = helicsFederateGetFilterByIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(271, varargin{:});
end
