function varargout = helicsEndpointGetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(236, varargin{:});
end
