function varargout = helicsInputGetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(198, varargin{:});
end
