function varargout = helicsBrokerGetIdentifier(varargin)
  [varargout{1:nargout}] = helicsMEX(50, varargin{:});
end
