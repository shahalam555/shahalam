function varargout = helicsFederateRegisterInterfaces(varargin)
  [varargout{1:nargout}] = helicsMEX(89, varargin{:});
end
