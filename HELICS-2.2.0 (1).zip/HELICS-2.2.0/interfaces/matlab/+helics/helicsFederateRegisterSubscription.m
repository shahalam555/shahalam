function varargout = helicsFederateRegisterSubscription(varargin)
  [varargout{1:nargout}] = helicsMEX(136, varargin{:});
end
