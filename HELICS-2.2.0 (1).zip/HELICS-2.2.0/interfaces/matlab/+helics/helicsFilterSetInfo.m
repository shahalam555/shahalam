function varargout = helicsFilterSetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(281, varargin{:});
end
