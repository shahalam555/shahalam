function varargout = helicsInputGetRawValueSize(varargin)
  [varargout{1:nargout}] = helicsMEX(165, varargin{:});
end
