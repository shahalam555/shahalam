function varargout = helicsCoreIsConnected(varargin)
  [varargout{1:nargout}] = helicsMEX(46, varargin{:});
end
