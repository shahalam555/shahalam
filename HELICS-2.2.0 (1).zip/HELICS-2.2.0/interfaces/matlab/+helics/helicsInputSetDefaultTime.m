function varargout = helicsInputSetDefaultTime(varargin)
  [varargout{1:nargout}] = helicsMEX(182, varargin{:});
end
