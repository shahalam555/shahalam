function varargout = helicsFederateEnterExecutingMode(varargin)
  [varargout{1:nargout}] = helicsMEX(99, varargin{:});
end
