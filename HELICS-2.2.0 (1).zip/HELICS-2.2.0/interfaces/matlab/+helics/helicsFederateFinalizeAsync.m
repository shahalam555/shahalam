function varargout = helicsFederateFinalizeAsync(varargin)
  [varargout{1:nargout}] = helicsMEX(91, varargin{:});
end
