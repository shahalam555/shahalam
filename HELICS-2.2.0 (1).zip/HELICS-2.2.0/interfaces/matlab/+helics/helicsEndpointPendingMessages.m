function varargout = helicsEndpointPendingMessages(varargin)
  [varargout{1:nargout}] = helicsMEX(225, varargin{:});
end
