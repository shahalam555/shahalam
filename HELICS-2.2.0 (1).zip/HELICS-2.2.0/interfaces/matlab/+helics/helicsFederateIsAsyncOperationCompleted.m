function varargout = helicsFederateIsAsyncOperationCompleted(varargin)
  [varargout{1:nargout}] = helicsMEX(97, varargin{:});
end
