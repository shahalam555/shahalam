function varargout = helicsInputGetChar(varargin)
  [varargout{1:nargout}] = helicsMEX(173, varargin{:});
end
