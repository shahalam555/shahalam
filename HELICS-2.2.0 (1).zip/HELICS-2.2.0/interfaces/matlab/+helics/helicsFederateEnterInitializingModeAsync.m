function varargout = helicsFederateEnterInitializingModeAsync(varargin)
  [varargout{1:nargout}] = helicsMEX(96, varargin{:});
end
