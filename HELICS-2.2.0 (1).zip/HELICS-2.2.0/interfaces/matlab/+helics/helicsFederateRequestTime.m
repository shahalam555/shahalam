function varargout = helicsFederateRequestTime(varargin)
  [varargout{1:nargout}] = helicsMEX(107, varargin{:});
end
