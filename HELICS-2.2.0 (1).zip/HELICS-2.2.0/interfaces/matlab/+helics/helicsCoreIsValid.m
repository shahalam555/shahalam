function varargout = helicsCoreIsValid(varargin)
  [varargout{1:nargout}] = helicsMEX(36, varargin{:});
end
