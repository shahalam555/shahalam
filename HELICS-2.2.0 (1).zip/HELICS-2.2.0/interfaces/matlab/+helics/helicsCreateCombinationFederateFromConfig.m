function varargout = helicsCreateCombinationFederateFromConfig(varargin)
  [varargout{1:nargout}] = helicsMEX(67, varargin{:});
end
