function varargout = helicsEndpointSendMessage(varargin)
  [varargout{1:nargout}] = helicsMEX(219, varargin{:});
end
