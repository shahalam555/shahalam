function varargout = helicsFederateGetMessage(varargin)
  [varargout{1:nargout}] = helicsMEX(228, varargin{:});
end
