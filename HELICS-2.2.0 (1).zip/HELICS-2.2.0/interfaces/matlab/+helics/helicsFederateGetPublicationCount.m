function varargout = helicsFederateGetPublicationCount(varargin)
  [varargout{1:nargout}] = helicsMEX(209, varargin{:});
end
