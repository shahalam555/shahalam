function varargout = helicsFederateGetCoreObject(varargin)
  [varargout{1:nargout}] = helicsMEX(106, varargin{:});
end
