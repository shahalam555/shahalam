function varargout = helicsCreateMessageFederateFromConfig(varargin)
  [varargout{1:nargout}] = helicsMEX(65, varargin{:});
end
