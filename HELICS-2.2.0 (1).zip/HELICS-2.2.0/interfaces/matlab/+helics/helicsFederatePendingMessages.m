function varargout = helicsFederatePendingMessages(varargin)
  [varargout{1:nargout}] = helicsMEX(224, varargin{:});
end
