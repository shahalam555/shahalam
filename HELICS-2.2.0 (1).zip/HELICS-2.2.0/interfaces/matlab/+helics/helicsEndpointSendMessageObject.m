function varargout = helicsEndpointSendMessageObject(varargin)
  [varargout{1:nargout}] = helicsMEX(220, varargin{:});
end
