function varargout = helicsInputLastUpdateTime(varargin)
  [varargout{1:nargout}] = helicsMEX(207, varargin{:});
end
