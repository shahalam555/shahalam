function varargout = helicsFederatePublishJSON(varargin)
  [varargout{1:nargout}] = helicsMEX(152, varargin{:});
end
