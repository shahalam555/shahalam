function varargout = helicsEndpointSetDefaultDestination(varargin)
  [varargout{1:nargout}] = helicsMEX(215, varargin{:});
end
