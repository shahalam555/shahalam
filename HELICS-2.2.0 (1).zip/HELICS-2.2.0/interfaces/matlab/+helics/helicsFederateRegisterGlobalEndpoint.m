function varargout = helicsFederateRegisterGlobalEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(212, varargin{:});
end
