function varargout = helicsFederateInfoFree(varargin)
  [varargout{1:nargout}] = helicsMEX(72, varargin{:});
end
