function varargout = helicsFederateGetName(varargin)
  [varargout{1:nargout}] = helicsMEX(115, varargin{:});
end
