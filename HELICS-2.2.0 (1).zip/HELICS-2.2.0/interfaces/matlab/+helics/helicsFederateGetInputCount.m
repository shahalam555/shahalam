function varargout = helicsFederateGetInputCount(varargin)
  [varargout{1:nargout}] = helicsMEX(210, varargin{:});
end
