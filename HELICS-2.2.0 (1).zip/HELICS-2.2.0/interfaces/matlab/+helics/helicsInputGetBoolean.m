function varargout = helicsInputGetBoolean(varargin)
  [varargout{1:nargout}] = helicsMEX(170, varargin{:});
end
