function varargout = helicsFederateCreateMessageObject(varargin)
  [varargout{1:nargout}] = helicsMEX(230, varargin{:});
end
