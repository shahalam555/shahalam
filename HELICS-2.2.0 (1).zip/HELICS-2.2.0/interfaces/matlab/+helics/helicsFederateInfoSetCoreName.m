function varargout = helicsFederateInfoSetCoreName(varargin)
  [varargout{1:nargout}] = helicsMEX(74, varargin{:});
end
