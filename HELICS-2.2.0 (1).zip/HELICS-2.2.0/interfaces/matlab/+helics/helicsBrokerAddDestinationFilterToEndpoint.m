function varargout = helicsBrokerAddDestinationFilterToEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(44, varargin{:});
end
