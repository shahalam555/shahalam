function varargout = helicsEndpointSendEventRaw(varargin)
  [varargout{1:nargout}] = helicsMEX(218, varargin{:});
end
