function varargout = helicsCoreSetReadyToInit(varargin)
  [varargout{1:nargout}] = helicsMEX(53, varargin{:});
end
