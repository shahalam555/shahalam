function varargout = helicsCreateValueFederateFromConfig(varargin)
  [varargout{1:nargout}] = helicsMEX(63, varargin{:});
end
