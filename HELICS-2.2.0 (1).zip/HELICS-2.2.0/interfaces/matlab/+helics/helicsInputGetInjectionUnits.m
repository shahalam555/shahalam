function varargout = helicsInputGetInjectionUnits(varargin)
  [varargout{1:nargout}] = helicsMEX(195, varargin{:});
end
