function varargout = helicsCreateValueFederate(varargin)
  [varargout{1:nargout}] = helicsMEX(62, varargin{:});
end
