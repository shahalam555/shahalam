function varargout = helicsCoreAddDestinationFilterToEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(49, varargin{:});
end
