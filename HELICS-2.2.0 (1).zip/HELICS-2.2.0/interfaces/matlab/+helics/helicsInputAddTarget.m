function varargout = helicsInputAddTarget(varargin)
  [varargout{1:nargout}] = helicsMEX(164, varargin{:});
end
