function varargout = helicsCleanupLibrary(varargin)
  [varargout{1:nargout}] = helicsMEX(135, varargin{:});
end
