function varargout = helicsFilterSetString(varargin)
  [varargout{1:nargout}] = helicsMEX(274, varargin{:});
end
