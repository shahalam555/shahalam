function varargout = helicsFederateGetFlagOption(varargin)
  [varargout{1:nargout}] = helicsMEX(121, varargin{:});
end
