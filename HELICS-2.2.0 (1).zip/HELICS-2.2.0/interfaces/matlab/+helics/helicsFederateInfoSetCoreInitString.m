function varargout = helicsFederateInfoSetCoreInitString(varargin)
  [varargout{1:nargout}] = helicsMEX(75, varargin{:});
end
