function varargout = helicsGetFederateByName(varargin)
  [varargout{1:nargout}] = helicsMEX(55, varargin{:});
end
