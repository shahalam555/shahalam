function varargout = helicsFederateRegisterTypeInput(varargin)
  [varargout{1:nargout}] = helicsMEX(142, varargin{:});
end
