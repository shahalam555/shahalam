function varargout = helicsIsCoreTypeAvailable(varargin)
  [varargout{1:nargout}] = helicsMEX(32, varargin{:});
end
