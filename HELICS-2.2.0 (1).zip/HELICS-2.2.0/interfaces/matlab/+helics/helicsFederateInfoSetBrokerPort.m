function varargout = helicsFederateInfoSetBrokerPort(varargin)
  [varargout{1:nargout}] = helicsMEX(81, varargin{:});
end
