function varargout = helicsInputIsUpdated(varargin)
  [varargout{1:nargout}] = helicsMEX(206, varargin{:});
end
