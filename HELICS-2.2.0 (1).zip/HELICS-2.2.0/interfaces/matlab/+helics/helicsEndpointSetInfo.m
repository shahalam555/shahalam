function varargout = helicsEndpointSetInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(237, varargin{:});
end
