function varargout = helicsFederateRequestTimeIterativeComplete(varargin)
  [varargout{1:nargout}] = helicsMEX(114, varargin{:});
end
