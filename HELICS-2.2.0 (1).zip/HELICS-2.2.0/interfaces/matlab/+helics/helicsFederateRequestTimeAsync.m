function varargout = helicsFederateRequestTimeAsync(varargin)
  [varargout{1:nargout}] = helicsMEX(111, varargin{:});
end
