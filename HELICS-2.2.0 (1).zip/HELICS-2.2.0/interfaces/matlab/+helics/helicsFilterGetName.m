function varargout = helicsFilterGetName(varargin)
  [varargout{1:nargout}] = helicsMEX(272, varargin{:});
end
