function varargout = helicsFederateInfoSetCoreTypeFromString(varargin)
  [varargout{1:nargout}] = helicsMEX(78, varargin{:});
end
