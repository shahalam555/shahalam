function varargout = helicsInputGetKey(varargin)
  [varargout{1:nargout}] = helicsMEX(191, varargin{:});
end
