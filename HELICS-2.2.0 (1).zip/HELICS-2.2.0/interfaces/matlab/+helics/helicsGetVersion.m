function varargout = helicsGetVersion(varargin)
  [varargout{1:nargout}] = helicsMEX(31, varargin{:});
end
