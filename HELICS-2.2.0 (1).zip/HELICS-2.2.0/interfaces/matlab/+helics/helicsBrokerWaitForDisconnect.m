function varargout = helicsBrokerWaitForDisconnect(varargin)
  [varargout{1:nargout}] = helicsMEX(45, varargin{:});
end
