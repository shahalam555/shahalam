function varargout = helicsFederateGetPublication(varargin)
  [varargout{1:nargout}] = helicsMEX(145, varargin{:});
end
