function varargout = helicsFederateRequestTimeAdvance(varargin)
  [varargout{1:nargout}] = helicsMEX(108, varargin{:});
end
