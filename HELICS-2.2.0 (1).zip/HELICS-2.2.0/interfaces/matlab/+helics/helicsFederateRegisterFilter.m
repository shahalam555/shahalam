function varargout = helicsFederateRegisterFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(263, varargin{:});
end
