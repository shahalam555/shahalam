function varargout = helicsCreateFederateInfo(varargin)
  [varargout{1:nargout}] = helicsMEX(69, varargin{:});
end
