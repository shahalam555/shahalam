function varargout = helicsFederateRequestTimeIterative(varargin)
  [varargout{1:nargout}] = helicsMEX(110, varargin{:});
end
