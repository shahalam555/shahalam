function varargout = helicsInputSetDefaultDouble(varargin)
  [varargout{1:nargout}] = helicsMEX(184, varargin{:});
end
