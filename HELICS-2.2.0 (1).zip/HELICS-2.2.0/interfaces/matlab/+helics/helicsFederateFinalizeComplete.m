function varargout = helicsFederateFinalizeComplete(varargin)
  [varargout{1:nargout}] = helicsMEX(92, varargin{:});
end
