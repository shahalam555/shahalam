function varargout = helicsEndpointGetMessage(varargin)
  [varargout{1:nargout}] = helicsMEX(226, varargin{:});
end
