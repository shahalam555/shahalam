function varargout = helicsFederateGetFilter(varargin)
  [varargout{1:nargout}] = helicsMEX(270, varargin{:});
end
