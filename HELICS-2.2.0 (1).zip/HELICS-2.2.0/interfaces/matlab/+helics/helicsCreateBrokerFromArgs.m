function varargout = helicsCreateBrokerFromArgs(varargin)
  [varargout{1:nargout}] = helicsMEX(38, varargin{:});
end
