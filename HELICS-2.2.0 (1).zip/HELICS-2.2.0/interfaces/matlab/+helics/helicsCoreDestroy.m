function varargout = helicsCoreDestroy(varargin)
  [varargout{1:nargout}] = helicsMEX(59, varargin{:});
end
