function varargout = helicsEndpointSubscribe(varargin)
  [varargout{1:nargout}] = helicsMEX(221, varargin{:});
end
