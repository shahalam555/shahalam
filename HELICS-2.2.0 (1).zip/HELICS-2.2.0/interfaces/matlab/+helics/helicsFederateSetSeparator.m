function varargout = helicsFederateSetSeparator(varargin)
  [varargout{1:nargout}] = helicsMEX(118, varargin{:});
end
