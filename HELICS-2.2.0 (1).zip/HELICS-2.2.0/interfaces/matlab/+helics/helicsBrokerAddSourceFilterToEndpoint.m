function varargout = helicsBrokerAddSourceFilterToEndpoint(varargin)
  [varargout{1:nargout}] = helicsMEX(43, varargin{:});
end
