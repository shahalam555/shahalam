function varargout = helicsEndpointHasMessage(varargin)
  [varargout{1:nargout}] = helicsMEX(223, varargin{:});
end
