function varargout = helicsFederateGetTimeProperty(varargin)
  [varargout{1:nargout}] = helicsMEX(120, varargin{:});
end
