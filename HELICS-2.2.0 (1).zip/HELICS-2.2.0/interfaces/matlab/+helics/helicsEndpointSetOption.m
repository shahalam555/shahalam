function varargout = helicsEndpointSetOption(varargin)
  [varargout{1:nargout}] = helicsMEX(238, varargin{:});
end
