function varargout = helicsFederateRequestTimeIterativeAsync(varargin)
  [varargout{1:nargout}] = helicsMEX(113, varargin{:});
end
