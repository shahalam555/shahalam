function varargout = helicsGetOptionIndex(varargin)
  [varargout{1:nargout}] = helicsMEX(84, varargin{:});
end
