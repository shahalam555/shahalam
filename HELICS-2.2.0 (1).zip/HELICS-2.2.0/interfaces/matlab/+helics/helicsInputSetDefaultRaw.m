function varargout = helicsInputSetDefaultRaw(varargin)
  [varargout{1:nargout}] = helicsMEX(178, varargin{:});
end
