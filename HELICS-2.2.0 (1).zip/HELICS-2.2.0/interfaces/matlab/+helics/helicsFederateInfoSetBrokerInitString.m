function varargout = helicsFederateInfoSetBrokerInitString(varargin)
  [varargout{1:nargout}] = helicsMEX(76, varargin{:});
end
