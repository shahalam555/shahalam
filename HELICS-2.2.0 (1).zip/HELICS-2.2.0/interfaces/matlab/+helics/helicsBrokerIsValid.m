function varargout = helicsBrokerIsValid(varargin)
  [varargout{1:nargout}] = helicsMEX(40, varargin{:});
end
