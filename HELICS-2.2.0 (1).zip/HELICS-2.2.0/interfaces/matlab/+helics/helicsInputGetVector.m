function varargout = helicsInputGetVector(varargin)
  [varargout{1:nargout}] = helicsMEX(176, varargin{:});
end
