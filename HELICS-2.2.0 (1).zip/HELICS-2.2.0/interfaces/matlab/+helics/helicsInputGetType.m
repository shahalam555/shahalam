function varargout = helicsInputGetType(varargin)
  [varargout{1:nargout}] = helicsMEX(188, varargin{:});
end
