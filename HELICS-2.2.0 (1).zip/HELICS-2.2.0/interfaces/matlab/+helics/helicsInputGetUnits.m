function varargout = helicsInputGetUnits(varargin)
  [varargout{1:nargout}] = helicsMEX(194, varargin{:});
end
