#include <variant>

int main()
{
    std::variant<int,double> b = 5;
    return 0;
}

