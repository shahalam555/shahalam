#include <expirimental/string_view>

int main()
{
    std::expirimental::string_view X("string");
    return 0;
}

