#include <optional>

int main()
{
    std::optional<int> b = 5;
    return 0;
}

