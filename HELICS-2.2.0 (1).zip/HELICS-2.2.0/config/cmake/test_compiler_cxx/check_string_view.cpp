#include <string_view>

int main()
{
    std::string_view X("string");
    return 0;
}

